module practica1 {
	requires org.junit.jupiter.api;
}

