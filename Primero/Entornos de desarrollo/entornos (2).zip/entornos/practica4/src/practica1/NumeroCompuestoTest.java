package practica1;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class NumeroCompuestoTest {
		
		static NumeroCompuesto numero1;
		static NumeroCompuesto numero2;
		static NumeroCompuesto numero3;
		
		static int test_numeroTest;
		
		@BeforeAll
		static void inicializar() {
		
			numero1 = new NumeroCompuesto(23);
			numero2 = new NumeroCompuesto(76);
			numero3 = new NumeroCompuesto(6);
			
			test_numeroTest = 0;
		}
		
		
		@BeforeEach
		void cuentaTest() {
			test_numeroTest++;
		}
		
		@Disabled		
		@Test
		void test() {
			fail("Not yet implemented");
		}
		
		@Test
		public void compararNumero() {
			assertEquals(false,numero1.equals(numero3));
			assertEquals(false,numero2.equals(numero1));
			assertEquals(false,numero3.equals(numero2));
		}

		 @AfterAll
		static void testFin() {
			 System.out.println("se termina con el afterall");
		}
		
		

	}
