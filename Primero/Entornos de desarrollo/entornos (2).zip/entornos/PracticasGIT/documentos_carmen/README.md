# Practica1_clase
practica 1 del instituto
