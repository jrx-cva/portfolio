# diarioconfinamiento
Relflexión colaborativa de todo el alumnado de la clase 1º DAM 2019/20
Esta es la práctica que estamos realizando del uso de Github para trabajar con control de versiones
El objetivo es que todo el alumnado escriba una reflexión en el documento compartido diarioconfinamiento.odt
Para ello:
Clonaréis el repositorio origen
Modificaréis el documento
Notificaréis al autor su modificación
