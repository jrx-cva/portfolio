<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relación 1</title>
</head>

<body>
    <?php
$entero = 1234; // variables de tipo entero
$punFlo = 5.4; // punto flotante
$carac = 'relación'; // cadena de caracteres
$verdadero = true; 
$falso = false;

//ejercicio 1
echo $entero + $punFlo. "<br>";
echo $entero - $punFlo. "<br>";
echo $entero * $punFlo. "<br>";
echo $entero / $punFlo. "<br>";
echo $carac."<br>";
    
//ejercicio 2
//$numero=$_REQUEST[numero];   
$numero = 73;    
    
print "<p>Tu número es $numero -> </p>\n";
    
if ($numero>50){
    echo $numero. ' es mayor que 50';
}else {
    echo $numero. ' no es mayor que 50';
}
echo "<br>";    
    
    
//ejercicio 5
$numero2=55;
    
print "<p>Tu número es $numero2 -></p>\n";
    
if ($numero2%3==0){
    echo $numero2. ' es divisible por 3';
}else {
    echo $numero2. ' no es divisible por 3';
}
echo "<br>";
    

//ejercicio 7
    $numInicial=30;
    $numFinal=50;
while($numFinal>$numInicial){
    echo $numInicial++."<br>";
}
echo "<br>";


//ejercicio 8
    $numero3=65;
    $suma=0;
    print "<p>Tu número es $numero3 -></p>\n";
    if($numero3>0){
        for ($i=1;$i<=$numero3;$i++){
            //$i=$sumatorio;
             ($suma+=$i);
        }
        echo $suma;
    }
    else{
        echo "Error";
    }

echo "<br>";


?>

</body>

</html>
