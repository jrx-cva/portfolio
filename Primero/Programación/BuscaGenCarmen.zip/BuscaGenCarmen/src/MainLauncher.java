

public class MainLauncher {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MainFrame mainFrame = new MainFrame("BuscaGen FASTA v1.0"); 
       

                mainFrame.setVisible(true); //activamos la ventana principal para que sea "pintable"        
        	
	}

}
