package com.iespablopicasso;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.io.FileNotFoundException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LanzadorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Controlador miControlador;
		
		JFrame fMain = new JFrame("Sporty World Java Swing"); 
		JPanel fondo = new JPanel();
		
		fondo.setBackground(Color.blue);
		
		
		//fondo.setLayout(new BoxLayout(fondo,BoxLayout.Y_AXIS));
		//fondo.setLayout(new FlowLayout(FlowLayout.RIGHT,60,60));
		//fondo.setLayout(new FlowLayout(FlowLayout.LEFT,60,60));
		//fondo.setLayout(new FlowLayout(FlowLayout.TRAILING,60,60));
		
		
		//Panel para los TextFields y los JLabel
		JPanel TextBoxsPanel = new JPanel();
		
		TextBoxsPanel.setBackground(Color.magenta);
		
		//Panel para el resultado
		JPanel ResultsPanel = new JPanel(new BorderLayout());
		
		ResultsPanel.setBackground(Color.green);
		
		
		fMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
		fMain.setSize(400, 300); 
		
		
		//Añadimos los componentes
		JLabel laMinutos = new JLabel("Minutos");       
        JTextField tfMinutos = new JTextField(5); // acepta hasta 5 caracteres 
        JLabel laKgs = new JLabel("Kilogramos");       
        JTextField tfKgs= new JTextField(3); // acepta hasta 5 caracteres 
        JComboBox cbEjercicios = new JComboBox();
        JLabel laKCal = new JLabel("KCal:"); 
        JLabel laKCalResult = new JLabel(""); 
        JButton buCalcular = new JButton("Calcular");  
        miControlador = new Controlador(tfMinutos,tfKgs,cbEjercicios,laKCalResult);
        buCalcular.addActionListener(miControlador);
        
        try {
			miControlador.iniciaDatos();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
   
        
        //Aquí añadimos al panel de TextFields y Jpanels sus componentes
        TextBoxsPanel.add(laMinutos);  
        TextBoxsPanel.add(tfMinutos); 
        TextBoxsPanel.add(laKgs); 
        TextBoxsPanel.add(tfKgs);
        
        
        //Aquí un ejemplo de añadir componentes al BorderLayout
        ResultsPanel.add(BorderLayout.WEST,laKCal); 
        ResultsPanel.add(BorderLayout.EAST,laKCalResult);
        ResultsPanel.add(BorderLayout.SOUTH,buCalcular);
        
        fondo.add(TextBoxsPanel);
        
        fondo.add(cbEjercicios); //Va directo al Fondo. Es un componente que no tiene panel intermedio
        
        fondo.add(ResultsPanel);
           
        
        fMain.add(fondo);
        
        
        
        //fMain.pack();
        
       
        
        fMain.setVisible(true); 

	}

}
