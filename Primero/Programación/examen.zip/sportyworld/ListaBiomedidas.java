package com.iespablopicasso.sportyworld;

import java.io.Serializable;
import java.util.ArrayList;

public class ListaBiomedidas implements Serializable {

    //creamos arrayList
    private ArrayList<Biometrica> listaBiomedidas = new ArrayList<>();

    public ListaBiomedidas() {

    }

    public void addBiomedidas(Biometrica nuevaBiomedida) {
        listaBiomedidas.add(nuevaBiomedida);
    }

    public ArrayList<Biometrica> getListaBiomedidas() {
        return listaBiomedidas;
    }
}
