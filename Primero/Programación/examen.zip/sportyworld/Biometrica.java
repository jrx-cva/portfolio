package com.iespablopicasso.sportyworld;

import java.io.Serializable;

public class Biometrica implements Serializable {

    /**
     *
     * ESTADO
     *
     */

    protected String usuario;
    protected String peso;
    protected String fecha;
    protected String hora;



    /**
     *
     * COMPORTAMIENTOS
     *
     */

    /**
     *
     * CONSTRUCTOR
     *
     */
    public Biometrica(String serializado) {
        String[] trozo;
        trozo = serializado.split(";");
        usuario = trozo[0];
        peso = trozo[1];
        fecha = trozo[2];
        hora = trozo[3];

    }


    public Biometrica(String user, String weight, String date, String hour) {
        this.usuario = user;
        this.peso = weight;
        this.fecha = date;
        this.hora = hour;

    }

    public String getUsuario() {
        return usuario;
    }

    public String getPeso() {
        return peso;
    }

    public String serializarAcesso() {
        return usuario + ";" +  peso + ";"  +  fecha + ";" +  hora ;
    }

    @Override
    public String toString() {
        return "Biometrica{" +
                "usuario='" + usuario + '\'' +
                ", peso='" + peso + '\'' +
                ", fecha='" + fecha + '\'' +
                ", hora='" + hora + '\'' +
                '}';
    }
}
