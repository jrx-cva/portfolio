package com.iespablopicasso.sportyworld;

public class Acceso {
    //ESTADO

    protected String user;
    protected String passwd;
    protected String dni;
    protected String fecha;
    protected String hora;

    //Comportamientos

    //Constructor
    public Acceso(String serializado) {
        String[] trozos;
        trozos = serializado.split(";");
        user = trozos[0];
        passwd = trozos[1];
        dni = trozos[2];
        fecha = trozos[3];
        hora = trozos[4];
    }

    public Acceso(String user,String passwd,String dni,String fecha,String hora) {
        this.user= user;
        this.passwd=passwd;
        this.dni=dni;
        this.fecha=fecha;
        this.hora=hora;
    }

    public String getUser() {
        return user;
    }

    public String getPasswd() {
        return passwd;
    }

    /*public boolean test(String otrouser, String otropasswd) {
        return (otrouser.equals(user) && otropasswd.equals(passwd));
    }*/

    public String serializarAcesso() {
        return user + ";" +  passwd + ";" +  dni + ";" +  fecha + ";" +  hora ;
    }
}
