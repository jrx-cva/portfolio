package com.iespablopicasso.sportyworld;

import java.util.ArrayList;

public class AccesosASistema {
    private ArrayList<Acceso> listaAcceso = new ArrayList();

    public AccesosASistema() {

    }




    public void addAcceso(Acceso accesoNuevo) {
        listaAcceso.add(accesoNuevo);
    }
}
