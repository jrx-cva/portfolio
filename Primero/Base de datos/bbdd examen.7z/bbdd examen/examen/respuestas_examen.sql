/*1. Listar los nombres de los clientes que tienen asignado el representante Alvaro Jaumes.*/
select nombre from empleados,clientes where 

/*2.Obtener una lista de todos los productos indicando para cada uno su idfab, idproducto, descripción, precio y precio con I.V.A. incluido (es el precio anterior aumentado en un 21%)..*/
select * SELECT idfab, idproducto, descripcion,precio, precio*(1+0.21) FROM productos;

/*3. Contar y agrupar por oficina los empleados con ventas menores a 600000.*/
SELECT ventas,nombre,oficina FROM oficinas WHERE oficina IN (SELECT oficina FROM
oficinas WHERE ventas<600000);

/*4. Obtener la lista de los clientes agrupados por código de representante asignado, visualizar todas la columnas de la tabla.*/
SELECT nombre,
/*5. Calcular el promedio del valor de las cuotas agrupadas por oficina.*/

/*6. Obtener los pedidos ordenados por fecha de pedido.*/
select * from pedidos order by fechapedido DESC;  

/*7. Listar las dos líneas de pedido más caras (las de mayor importe).*/
select numpedido,max(importe) from pedidos;

/*8. Obtener los valores de nombre de empleado en orden alfabético de los empleados que tienen la misma edad que Antonio Viguer.*/
select nombre from empleados where edad=45 order by nombre;

/*9. Queremos ver el par jefe y cantidad de empleados por cada jefe.*/

/*10. Total de empleados agrupados por oficina.*/

/*11. Listar los números de las oficinas que no tienen director.*/

/*12. Saber cuántas oficinas tienen empleados con ventas superiores a su cuota, no queremos saber cuales sino cuántas hay.*/