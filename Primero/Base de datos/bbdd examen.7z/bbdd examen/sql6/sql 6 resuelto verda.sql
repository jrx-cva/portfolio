/*1. Visualizar el número de empleados de cada departamento (utilizar GROUP BY).*/
select dnombre, count(emp_no) from emple,depart where emple.dept_no = depart.dept_no group by dnombre;

/*2. Visualizar los departamentos con más de 5 empleados (Utilizar GROUP BY para agrupar por departamento y HAVING para establecer la condición sobre los grupos)*/
select dnombre, count(emp_no) from emple,depart where emple.dept_no = depart.dept_no group by dnombre having count(emp_no)>5;

/*3. Hallar la media de los salarios de cada departamento (utilizar avg y GROUP BY). */
select dnombre, avg(salario) from emple, depart where emple.dept_no = depart.dept_no group by dnombre;

/*4. Visualizar el nombre de los empleados vendedores del departamento ʻVENTASʼ */
select apellido, oficio, dnombre from emple, depart where emple.dept_no = depart.dept_no and dnombre='VENTAS' and oficio='VENDEDOR';

/*5. Visualizar el número de vendedores del departamento ʻVENTASʼ (utilizar la función COUNT sobre la consulta anterior).*/
select count(apellido) from emple, depart where emple.dept_no = depart.dept_no and dnombre='ventas' and oficio='vendedor';

/*6. Visualizar los oficios de los empleados del departamento ʻVENTASʼ.*/
select apellido, oficio, dnombre from emple, depart where emple.dept_no = depart.dept_no and dnombre='ventas';

/*7. A partir de la tabla EMPLE, visualizar el número de empleados de cada departamento cuyo oficio sea ʻEMPLEADOʼ (utilizar GROUP BY para agrupar por departamento. En la cláusula WHERE habrá que indicar que el oficio es ʻEMPLEADOʼ).*/
select emp_no, dnombre, oficio from emple, depart where emple.dept_no = depart.dept_no and oficio='empleado' group by dnombre;

/*8. Visualizar el departamento con más empleados.*/
select dnombre, max(emp_no) from emple, depart where emple.dept_no = depart.dept_no;

/*9. Mostrar los departamentos cuya suma de salarios sea mayor que la media de salarios de todos los empleados. */
select dnombre as "Departamento", sum(salario), MediaSalarioTotal from emple, depart, (select avg(salario) as "MediaSalarioTotal" from emple) as TablaNueva where emple.dept_no = depart.dept_no group by dnombre having sum(salario) > MediaSalarioTotal;

/*10. Para cada oficio obtener la suma de salarios.*/
select oficio, sum(salario) from emple group by oficio;

/*11. Visualizar la suma de salarios de cada oficio del departamento ʻVENTASʼ.*/
select sum(salario), oficio, dnombre from emple, depart where emple.dept_no = depart.dept_no and dnombre= 'ventas' group by oficio;

/*12. Visualizar el número de departamento que tenga más empleados cuyo oficio sea empleado.*/
select dept_no, max(emp_no), oficio from emple where oficio='empleado' group by dept_no;

/*13. Mostrar el número de oficios distintos de cada departamento*/
select dnombre, count(oficio) from emple, depart where emple.dept_no = depart.dept_no group by dnombre;

/*14. Mostrar los departamentos que tengan más de dos personas trabajando en la misma profesión.*/
select dnombre, count(oficio) from emple, depart where emple.dept_no = depart.dept_no group by dnombre, oficio having count(oficio)>2;

/*15. Dada la tabla HERRAMIENTAS, visualizar por cada estantería la suma de las unidades*/
select estanteria, sum(unidades) from herramientas group by estanteria;

/*16. Visualizar la estantería con más unidades de la tabla HERRAMIENTAS.*/
select estanteria, max(unidades) from herramientas;

/*17. Mostrar el número de médicos que pertenecen a cada hospital, ordenado por número descendente de hospital.*/
select count(*) as "Médicos" , cod_hospital from medicos group by cod_hospital order by cod_hospital DESC; 

/*18. Realizar una consulta en la que se muestre por cada hospital el nombre de las especialidades que tiene.*/
select cod_hospital, especialidad from medicos group by cod_hospital, especialidad;

/*19. Realizar una consulta en la que aparezca por cada hospital y en cada especialidad el número de médicos (utilizar GROUP BY).*/
select count(*), cod_hospital, especialidad from medicos group by cod_hospital, especialidad;

/*20. Obtener por cada hospital el número de empleados.*/
select cod_hospital, count(*) from medicos group by cod_hospital;

/*21. Obtener por cada especialidad el número de trabajadores.*/
select especialidad, count(*) from medicos group by especialidad;

/*22. Visualizar la especialidad que tenga más médicos.*/
select especialidad from medicos group by especialidad having count(*) = (select max(Medicos) from (select count(*) as "Medicos" from medicos group by especialidad) as Tabla); 

/*23. ¿Cuál es el nombre del hospital que tiene mayor número de plazas?*/
select nombre from hospitales where num_plazas = (select max(num_plazas) from hospitales);

/*24. Visualizar las diferentes estanterías de la tabla HERRAMIENTAS ordenados descendentemente por estantería.*/
select * from herramientas group by estanteria order by estanteria DESC;

/*25. Averiguar cuántas unidades tiene cada estantería.*/
select unidades, estanteria from herramientas group by estanteria;

/*26. Visualizar las estanterías que tengan más de 15 unidades*/
select estanteria, sum(unidades) from herramientas group by estanteria having sum(unidades)>15;

/*27. ¿Cuál es la estantería que tiene más unidades?*/
select estanteria from herramientas group by estanteria having sum(unidades) = (select max(Suma) from (select sum(unidades) as "Suma" from herramientas group by estanteria) as Tabla);

/*28. A partir de las tablas EMPLE y DEPART mostrar los datos del departamento que no tiene ningún empleado.*/
select dnombre, depart.dept_no, loc from emple right outer join depart on emple.dept_no=depart.dept_no where emp_no is null;

/*29. Mostrar el número de empleados de cada departamento. En la salida se debe mostrar también los departamentos que no tienen ningún
empleado.*/
select dnombre, count(emp_no) 'Nº empleados' from emple right outer join depart on emple.dept_no=depart.dept_no group by dnombre;

/*30. Obtener la suma de salarios de cada departamento, mostrando las columnas DEPT_NO, SUMA DE SALARIOS y DNOMBRE. En el resultado
también se deben mostrar los departamentos que no tienen asignados empleados.*/
select dnombre, depart.dept_no, sum(salario) from emple right outer join depart on emple.dept_no=depart.dept_no group by dnombre;

/*31. Utilizar la función IFNULL en la consulta anterior para que en el caso de que un departamento no tenga empleados, aparezca como suma de
salarios el valor 0.*/
select dnombre, ifnull(sum(salario),0) 'Nº empleados' from emple right outer join depart on emple.dept_no=depart.dept_no group by dnombre;

/*32. Obtener el número de médicos que pertenecen a cada hospital, mostrando las columnas COD_HOSPITAL, NOMBRE y NÚMERO DE MÉDICOS. En el resultado deben aparecer también los datos de los hospitales que no tienen médicos.*/
select hospitales.cod_hospital, nombre, count(dni) 'Nº de médicos' from medicos right outer join hospitales on medicos.cod_hospital = hospitales.cod_hospital group by nombre;



