/*1*/
SELECT idfab, idproducto, descripcion,precio, precio*(1+0.16)
FROM productos;
/*2*/
SELECT numpedido,fab,producto,cant, ROUND(importe/cant),0,importe
FROM pedidos;
/*3*/
SELECT nombre, (YEAR(NOW())- YEAR(contrato))*365 'Días trabajados', YEAR(NOW()) - edad 'Año Nacimiento'
FROM empleados;
/*4*/
SELECT *
FROM clientes
GROUP BY repclie;
/*5*/
SELECT *
FROM oficinas
ORDER BY region,ciudad,oficina DESC;
/*6*/
SELECT *
FROM pedidos
ORDER BY fechapedido DESC;
/*7*/
SELECT *
FROM pedidos
ORDER BY importe DESC
LIMIT 4;
/*8*/
SELECT numpedido,fab,producto,cant, ROUND(importe/cant) precio_unitario,importe
FROM pedidos
ORDER BY precio_unitario
LIMIT 5;
/*9-->no hay ninguno*/
select * from pedidos where month(fechapedido)=3;
/*10*/
SELECT *
FROM empleados
WHERE oficina IS NOT NULL;
/*11*/
SELECT *
FROM oficinas
WHERE dir IS NULL;
/*33*/
SELECT COUNT(DISTINCT(oficinas.oficina))
FROM empleados,oficinas
WHERE oficinas.oficina=empleados.oficina AND empleados.ventas>cuota;
/*34*/
SELECT *
FROM clientes
WHERE repclie=(
SELECT numemp
FROM empleados
WHERE nombre='Alvaro Jaumes');
/*35*/
SELECT numemp,nombre,oficina
FROM empleados
WHERE oficina IN (
SELECT
oficina
FROM oficinas
WHERE ventas>objetivo);
/*38*/
SELECT *
FROM clientes
WHERE repclie=(
SELECT numemp
FROM empleados
WHERE nombre='Ana Bustamante') AND numclie=(
SELECT clie
FROM pedidos
WHERE importe < 3000);
/*39*/
SELECT empleados.oficina
FROM empleados,oficinas
WHERE
empleados.oficina=oficinas.oficina AND
empleados.ventas >= (objetivo*0.55);
/*40*/
SELECT *
FROM oficinas
WHERE
(objetivo * 0.5) <= (SELECT MIN(ventas) FROM empleados WHERE empleados.oficina = oficinas.oficina);
-- having count(*)=tabla_cuenta.cuenta_total;
/*41*/
SELECT oficinas.oficina, SUM(cuota),objetivo
FROM oficinas,empleados
WHERE
oficinas.oficina=empleados.oficina
GROUP BY oficinas.oficina
HAVING SUM(cuota)<oficinas.objetivo;
