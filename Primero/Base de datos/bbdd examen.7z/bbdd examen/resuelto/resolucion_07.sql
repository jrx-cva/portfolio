/*1*/
SELECT * FROM maillot;
/*2*/
SELECT dorsal, nombre, edad FROM ciclista WHERE edad <= 25;
/*3*/
SELECT nompuerto, altura FROM puerto WHERE categoria = "E";
/*4: No hay ninguna -->*/
SELECT netapa FROM etapa WHERE salida = llegada;
/*5*/
SELECT COUNT(*) "Nº ciclistas" FROM ciclista;
/*6*/
SELECT COUNT(*) "Nº ciclistas" FROM ciclista WHERE edad > 25;
/*7*/
SELECT COUNT(*) "Nº de equipos" FROM equipo;
/*8*/
SELECT ROUND(AVG(edad)) "Media de edad" FROM ciclista;
/*9*/
SELECT MIN(altura), MAX(altura) FROM puerto;
/*10*/
SELECT nombre, nomeq FROM ciclista;
/*11*/
SELECT nombre FROM ciclista WHERE nomeq = "Banesto";
/*12*/
SELECT COUNT(nombre) FROM ciclista WHERE nomeq = "Amore Vita";
/*13*/
SELECT AVG(edad) FROM ciclista WHERE nomeq = "TVM";
/*14*/
SELECT nombre FROM ciclista WHERE nomeq = 
(SELECT nomeq FROM ciclista WHERE nombre="Miguel Indurain");
/*15*/
SELECT nombre FROM ciclista WHERE dorsal IN (SELECT dorsal FROM etapa);
/*16*/
SELECT DISTINCT(nombre) FROM ciclista 
JOIN llevar ON ciclista.dorsal = llevar.dorsal
JOIN maillot ON llevar.codigo = maillot.codigo
WHERE tipo="general";
/*17*/
SELECT nombre FROM ciclista WHERE edad =
(SELECT MIN(edad) FROM ciclista);
/*18*/
SELECT nomeq,COUNT(*) FROM ciclista GROUP BY nomeq;
/*19*/
SELECT nomeq,COUNT(*) FROM ciclista GROUP BY nomeq HAVING COUNT(*)>5;
/*20*/
SELECT nombre,COUNT(*) FROM ciclista,puerto WHERE
ciclista.dorsal=puerto.dorsal  GROUP BY nombre;
/*21*/
SELECT nombre,COUNT(*) FROM ciclista,puerto WHERE
ciclista.dorsal=puerto.dorsal  GROUP BY nombre HAVING COUNT(*)>1;
/*22*/
SELECT equipo.nomeq,equipo.director FROM equipo, ciclista
WHERE equipo.nomeq=ciclista.nomeq AND
edad > 33;
/*23*/
SELECT nombre, nomeq FROM ciclista WHERE nomeq != "Kelme";
/*24*/
SELECT nombre FROM ciclista WHERE dorsal NOT IN (SELECT dorsal FROM etapa);
/*25*/
SELECT nombre FROM ciclista WHERE dorsal NOT IN (SELECT dorsal FROM puerto);
/*26*/
SELECT nombre FROM ciclista WHERE dorsal IN (SELECT dorsal FROM puerto GROUP BY dorsal
HAVING COUNT(*)>1);
/*27*/
SELECT DISTINCT(nombre) FROM ciclista 
JOIN llevar ON ciclista.dorsal = llevar.dorsal
JOIN maillot ON llevar.codigo = maillot.codigo
WHERE tipo 
IN (SELECT tipo FROM ciclista 
JOIN llevar ON ciclista.dorsal = llevar.dorsal
JOIN maillot ON llevar.codigo = maillot.codigo
WHERE nombre='Miguel Indurain'
) AND nombre != 'Miguel Indurain';
/*28*/
SELECT nomeq 'Equipo', ROUND(AVG(edad)) 'Edad media', MAX(edad) 'Mayor edad', MIN(edad) 'Menor edad' 
FROM ciclista GROUP BY nomeq;
/*29*/
SELECT nombre, nomeq FROM ciclista WHERE edad BETWEEN 25 AND 30 AND nomeq NOT IN ('Kelme','Banesto');
/*30*/
SELECT nombre FROM ciclista, etapa WHERE ciclista.dorsal=etapa.dorsal AND salida = 'Zamora';
/*31*/
SELECT nombre,categoria FROM ciclista, puerto WHERE ciclista.dorsal=puerto.dorsal AND
nomeq='Banesto';
/*32*/
SELECT nompuerto, etapa.netapa, km FROM puerto,etapa WHERE puerto.netapa = etapa.netapa;
/*33*/
SELECT nombre, color FROM ciclista,llevar,maillot WHERE
ciclista.dorsal = llevar.dorsal AND llevar.codigo = maillot.codigo;
/*34*/
SELECT nombre, llevar.netapa, color, ciclista.dorsal FROM ciclista,llevar,maillot,etapa WHERE
ciclista.dorsal = llevar.dorsal AND llevar.codigo = maillot.codigo
 AND etapa.netapa = llevar.netapa AND color = 'amarillo';
/*35 COMPLETAR*/
SELECT etapa_llegada.netapa, etapa_llegada.llegada, etapa_salida.netapa, etapa_salida.salida
FROM etapa etapa_llegada, etapa etapa_salida
WHERE etapa_llegada.netapa+1 = etapa_salida.netapa AND
etapa_llegada.llegada NOT LIKE etapa_salida.salida;
/*36*/
SELECT netapa, salida FROM etapa WHERE netapa NOT IN (SELECT netapa FROM puerto);
/*37*/
SELECT ROUND(AVG(edad)) FROM ciclista WHERE dorsal IN (SELECT dorsal FROM etapa);
/*38*/
SELECT nompuerto FROM puerto
 WHERE altura > (SELECT AVG(altura) FROM puerto);
/*39*/
SELECT salida, llegada FROM etapa,puerto WHERE etapa.netapa=puerto.netapa AND
pendiente = (SELECT MAX(pendiente) FROM puerto);
/*40*/
SELECT nombre FROM ciclista,puerto WHERE ciclista.dorsal=puerto.dorsal AND
pendiente = (SELECT MAX(pendiente) FROM puerto);
