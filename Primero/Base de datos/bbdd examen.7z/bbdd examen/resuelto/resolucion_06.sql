/*1*/
select dnombre as "Nombre de departamento", count(emp_no) from emple, depart where
emple.dept_no = depart.dept_no group by dnombre;
/*2*/
select dnombre as "Departamento", count(emp_no) as "Nº empleados" from emple, depart where
emple.dept_no = depart.dept_no group by dnombre having count(emp_no) > 5;
/*3*/
select dnombre as "Nombre de departamento", avg(salario) from emple, depart where
emple.dept_no = depart.dept_no group by dnombre;
/*4*/
select apellido, oficio, dnombre as "Nombre de departamento" from emple, depart where
emple.dept_no = depart.dept_no and dnombre='ventas' and oficio='vendedor';
/*5*/
select count(apellido) as "Nº vendedores de Ventas" from emple, depart where
emple.dept_no = depart.dept_no and dnombre='ventas' and oficio='vendedor';
/*6*/
select distinct(oficio) from emple, depart where emple.dept_no = depart.dept_no and dnombre='ventas';
/*7*/
select dnombre as "Nombre de departamento", count(emp_no) as "Nº de empleados con ofcio 'Empleado'" from emple, depart where
emple.dept_no = depart.dept_no and oficio = 'empleado' group by dnombre;
/*8*/
select dept_no from emple group by dept_no having count(*) = ( select max(NumPorDepart) from 
(select count(*) as "NumPorDepart" from emple group by dept_no) as GrupoEmple);
/*9*/
select dnombre as "Departamento", avg(salario), MediaSalarioTotal from 
depart, emple, (select avg(salario) as "MediaSalarioTotal" from emple) as Mtabla  
where emple.dept_no = depart.dept_no
group by dnombre having avg(salario) > (select avg(salario) from emple);
/*10*/
select oficio, sum(salario) from emple group by oficio;
/*11*/
select oficio, sum(salario) from emple,depart where emple.dept_no = depart.dept_no and dnombre='ventas' group by oficio;
/*12*/
select dept_no from emple where oficio = "empleado" group by dept_no having count(*) = (
select max(NumEmpleado) from
(select count(*) as "NumEmpleado" from emple where oficio = 'empleado' group by dept_no) as CuentaEmpleado);
/*13*/
select dnombre, count(distinct(oficio)) from emple,depart where emple.dept_no = depart.dept_no group by dnombre;
/*14*/
select dnombre, count(oficio) from emple,depart where emple.dept_no = depart.dept_no group by dnombre, oficio having count(oficio) > 2;
/*15*/
select estanteria, sum(unidades) as 'SUMA' from herramientas group by estanteria order by estanteria;
/*16*/
select estanteria, max(sum(unidades)) from herramientas group by estanteria;
/*17*/
select hospitales.nombre as "Hospital", count(apellidos) as "Nº de médicos" from medicos, hospitales where
hospitales.cod_hospital = medicos.cod_hospital group by nombre;
/*18*/
select  distinct(especialidad), nombre as "Hospital"  from medicos, hospitales where
hospitales.cod_hospital = medicos.cod_hospital order by nombre;
/*19*/
select  especialidad, nombre as "Hospital" , count(apellidos) as "Nº de médicos" from medicos, hospitales where
hospitales.cod_hospital = medicos.cod_hospital group by nombre order by nombre;
/*20*/
select nombre as "Hospital", count(*) from personas, hospitales where personas.cod_hospital=hospitales.cod_hospital
group by nombre;
/*21*/
select especialidad, count(*) from medicos group by especialidad;
/*22*/
select especialidad from medicos group by especialidad having count(*) =
(select max(NumMedicos) from
(select count(*) as "NumMedicos" from medicos group by especialidad) as TablaEspecialidad);
/*23*/
select nombre from hospitales where num_plazas = (select max(num_plazas) from hospitales);
/*24*/
select * from herramientas order by estanteria desc;
/*25*/
select estanteria, sum(unidades) from herramientas group by estanteria order by estanteria;
/*26*/
select estanteria, sum(unidades) from herramientas group by estanteria having sum(unidades) > 15 order by estanteria;
/*27*/
select estanteria from herramientas group by estanteria having sum(unidades) = (
select max(suma) from
(select sum(unidades) as "Suma" from herramientas group by estanteria) as SumaUnidades);
/*28*/
select dnombre, depart.dept_no, loc from emple right outer join depart on emple.dept_no=depart.dept_no where emp_no is null;
/*29*/
select dnombre, count(emp_no) 'Nº empleados' from emple right outer join depart on emple.dept_no=depart.dept_no group by dnombre;
/*30*/
select dnombre, depart.dept_no, sum(salario)
from emple right outer join depart on emple.dept_no=depart.dept_no 
group by dnombre;
/*31*/
select dnombre, ifnull(sum(salario),0) 'Nº empleados' 
from emple right outer join depart on emple.dept_no=depart.dept_no 
group by dnombre;
/*32*/
select hospitales.cod_hospital, nombre, count(dni) 'Nº de médicos'
from medicos right outer join hospitales on medicos.cod_hospital = hospitales.cod_hospital
group by nombre;

