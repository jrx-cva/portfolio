/*1 Obtener una lista de todos los productos indicando para cada uno su idfab, idproducto, descripción, precio y precio con I.V.A. incluido (es el precio anterior aumentado en un
16%).*/
SELECT idfab, idproducto, descripcion,precio, precio*(1+0.16) FROM productos;

/*2 De cada pedido queremos saber su número de pedido, fab, producto, cantidad, precio unitario e importe.*/
SELECT numpedido,fab,producto,cant, ROUND(importe/cant),0,importe FROM pedidos;

/*3 Listar de cada empleado su nombre, nº de días que lleva trabajando en la empresa y su año de nacimiento (suponiendo que este año ya ha cumplido años).*/
SELECT nombre, (YEAR(NOW())- YEAR(contrato))*365 'Días trabajados', YEAR(NOW()) - edad 'Año Nacimiento' FROM empleados;

/*4 Obtener la lista de los clientes agrupados por código de representante asignado, visualizar todas la columnas de la tabla.*/
SELECT * FROM clientes GROUP BY repclie;

/*5 Obtener las oficinas ordenadas por orden alfabético de región y dentro de cada región por ciudad, si hay más de una oficina en la misma ciudad, aparecerá primero la que
tenga el número de oficina mayor.*/
SELECT * FROM oficinas ORDER BY region,ciudad,oficina DESC;

/*6 Obtener los pedidos ordenados por fecha de pedido.*/
SELECT * FROM pedidos ORDER BY fechapedido DESC;

/*7 Listar las cuatro líneas de pedido más caras (las de mayor importe).*/
SELECT * FROM pedidos ORDER BY importe DESC LIMIT 4;

/*8 Obtener las mismas columnas que en el ejercicio 2 pero sacando únicamente las 5 líneas de pedido de menor precio unitario.*/
SELECT numpedido,fab,producto,cant, ROUND(importe/cant) precio_unitario,importe FROM pedidos ORDER BY precio_unitario LIMIT 5;

/*9 Listar toda la información de los pedidos de marzo.*/
select * from pedidos where month(fechapedido)=3;

/*10 Listar los números de los empleados que tienen una oficina asignada.*/
SELECT * FROM empleados WHERE oficina IS NOT NULL;

/*11 Listar los números de las oficinas que no tienen director.*/
SELECT * FROM oficinas WHERE dir IS NULL;

/*33 Saber cuántas oficinas tienen empleados con ventas superiores a su cuota, no queremos saber cuales sino cuántas hay.*/
SELECT COUNT(DISTINCT(oficinas.oficina)) FROM empleados,oficinas WHERE oficinas.oficina=empleados.oficina AND empleados.ventas>cuota;

/*34 Listar los nombres de los clientes que tienen asignado el representante Alvaro Jaumes (suponiendo que no pueden haber representantes con el mismo nombre).*/
SELECT * FROM clientes WHERE repclie=(SELECT numemp FROM empleados WHERE nombre='Alvaro Jaumes');

/*35 Listar los vendedores (numemp, nombre, y nº de oficina) que trabajan en oficinas "buenas" (las que tienen ventas superiores a su objetivo).*/
SELECT numemp,nombre,oficina FROM empleados WHERE oficina IN (SELECT oficina FROM oficinas WHERE ventas>objetivo);

/*38 Listar los clientes asignados a Ana Bustamante que no han remitido un pedido superior a 3000 pts.*/
SELECT * FROM clientes WHERE repclie=(SELECT numemp FROM empleados WHERE nombre='Ana Bustamante') AND numclie=(SELECT clie FROM pedidos WHERE importe < 3000);

/*39 Listar las oficinas en donde haya un vendedor cuyas ventas representen más del 55% del objetivo de su oficina.*/
SELECT empleados.oficina FROM empleados,oficinas WHERE empleados.oficina=oficinas.oficina AND empleados.ventas >= (objetivo*0.55);

/*40 Listar las oficinas en donde todos los vendedores tienen ventas que superan al 50% del objetivo de la oficina.*/
SELECT * FROM oficinas WHERE (objetivo * 0.5) <= (SELECT MIN(ventas) FROM empleados WHERE empleados.oficina = oficinas.oficina);

/*41 Listar las oficinas que tengan un objetivo mayor que la suma de las cuotas de sus vendedores.*/
SELECT oficinas.oficina, SUM(cuota),objetivo FROM oficinas,empleados WHERE oficinas.oficina=empleados.oficina GROUP BY oficinas.oficina HAVING SUM(cuota)<oficinas.objetivo;