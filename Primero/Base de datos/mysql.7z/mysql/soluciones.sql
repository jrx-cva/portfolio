/*ejercicio1*/
create view comercio_sur as select * from comercio where ciudad like 'Sevilla';

/*ejercicio2*/
insert into comercio values (8,'Carmen Velasco','Sevilla');

/*ejercicio3*/
create view malos_clientes as (select cliente.dni,cliente.nombre,cliente.edad from cliente left join registra on cliente.dni = registra.dni where registra.dni is null );

/*ejercicio4*/
create view comercios_ciudad as (select ciudad, count(nombre) as "Nº de Comercios" from comercio group by ciudad);

/*ejercicio5*/
create view producto as select cif,codigo,cantidad*10 from distribuye;

/*ejercicio6*/
create view cliente_registrado as select nombre, medio from cliente join registra on cliente.dni=registra.dni order by nombre;
