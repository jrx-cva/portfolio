create
    definer = root@localhost function Prefijo(cadena varchar(15), num_char int) returns varchar(15) deterministic
BEGIN
declare pre varchar(15);
set pre=concat(upper(left(cadena,num_char)),"-");

RETURN pre;
END;

