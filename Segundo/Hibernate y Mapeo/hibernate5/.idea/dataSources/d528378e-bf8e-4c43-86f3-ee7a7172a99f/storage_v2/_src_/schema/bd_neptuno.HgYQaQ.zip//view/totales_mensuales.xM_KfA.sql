create view totales_mensuales as
select year(`bd_neptuno`.`totales`.`fecha_pedido`)                                                                    AS `año`,
       month(`bd_neptuno`.`totales`.`fecha_pedido`)                                                                   AS `mes`,
       (`bd_neptuno`.`totales`.`fecha_pedido` +
        interval (1 - dayofmonth(`bd_neptuno`.`totales`.`fecha_pedido`)) day)                                         AS `fecha`,
       round(sum(`bd_neptuno`.`totales`.`cargo`), 0)                                                                  AS `cargo`,
       round(sum(`bd_neptuno`.`totales`.`importe`), 0)                                                                AS `importe`,
       round(sum(`bd_neptuno`.`totales`.`total`), 0)                                                                  AS `total`,
       count(`bd_neptuno`.`totales`.`id`)                                                                             AS `num_pedidos`
from `bd_neptuno`.`totales`
group by year(`bd_neptuno`.`totales`.`fecha_pedido`), month(`bd_neptuno`.`totales`.`fecha_pedido`);

