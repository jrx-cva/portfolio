create view v_empleados1 as
select `bd_neptuno`.`empleados`.`id`                 AS `id`,
       `bd_neptuno`.`empleados`.`apellidos`          AS `apellidos`,
       `bd_neptuno`.`empleados`.`nombre`             AS `nombre`,
       `bd_neptuno`.`empleados`.`cargo`              AS `cargo`,
       `bd_neptuno`.`empleados`.`tratamiento`        AS `tratamiento`,
       `bd_neptuno`.`empleados`.`fecha_nacimiento`   AS `fecha_nacimiento`,
       `bd_neptuno`.`empleados`.`fecha_contratacion` AS `fecha_contratacion`,
       `bd_neptuno`.`empleados`.`direccion`          AS `direccion`,
       `bd_neptuno`.`empleados`.`ciudad`             AS `ciudad`,
       `bd_neptuno`.`empleados`.`region`             AS `region`,
       `bd_neptuno`.`empleados`.`cp`                 AS `cp`,
       `bd_neptuno`.`empleados`.`pais`               AS `pais`,
       `bd_neptuno`.`empleados`.`telefono_domicilio` AS `telefono_domicilio`,
       `bd_neptuno`.`empleados`.`extension`          AS `extension`,
       `bd_neptuno`.`empleados`.`notas`              AS `notas`,
       `bd_neptuno`.`empleados`.`jefe_id`            AS `jefe_id`
from `bd_neptuno`.`empleados`;

