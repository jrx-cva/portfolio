create view totales as
select `p`.`id`                                        AS `id`,
       `p`.`fecha_pedido`                              AS `fecha_pedido`,
       `p`.`cliente_id`                                AS `cliente_id`,
       `p`.`empleado_id`                               AS `empleado_id`,
       `p`.`envio_id`                                  AS `envio_id`,
       `p`.`cargo`                                     AS `cargo`,
       sum(`bd_neptuno`.`i`.`importe`)                 AS `importe`,
       (`p`.`cargo` + sum(`bd_neptuno`.`i`.`importe`)) AS `total`
from (`bd_neptuno`.`pedidos` `p`
         join `bd_neptuno`.`importes` `i` on ((`p`.`id` = `bd_neptuno`.`i`.`pedido_id`)))
group by `p`.`id`;

