create
    definer = root@localhost function fn_factorial(n int) returns int deterministic
BEGIN

DECLARE factorial_final INT;
SET factorial_final = n ;
IF n <= 0 THEN
	RETURN 1;
END IF;

buclaso: LOOP
SET n = n - 1 ;
	IF n<1 THEN
	LEAVE buclaso;
	END IF;
SET factorial_final = factorial_final * n ;
END LOOP buclaso;

return factorial_final;

END;

