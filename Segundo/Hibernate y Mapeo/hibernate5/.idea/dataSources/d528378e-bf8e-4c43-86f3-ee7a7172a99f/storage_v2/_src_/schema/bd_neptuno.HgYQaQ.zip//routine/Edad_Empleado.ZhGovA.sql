create
    definer = root@localhost function Edad_Empleado(var_id int) returns int deterministic
BEGIN
	declare fecha_edad int;
    
	SELECT TIMESTAMPDIFF(YEAR, empleados.fecha_nacimiento, curdate()) into fecha_edad
    FROM empleados
    WHERE empleados.id=var_id;
    
	RETURN fecha_edad;
END;

