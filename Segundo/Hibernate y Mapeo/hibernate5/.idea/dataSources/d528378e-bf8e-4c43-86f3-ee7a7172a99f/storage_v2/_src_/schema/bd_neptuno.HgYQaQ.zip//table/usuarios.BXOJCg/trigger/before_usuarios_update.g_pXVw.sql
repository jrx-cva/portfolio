create definer = root@localhost trigger before_usuarios_update
    before update
    on usuarios
    for each row
begin
  insert into clavesanteriores(nombre, clave) values (old.nombre, old.clave); 
end;

