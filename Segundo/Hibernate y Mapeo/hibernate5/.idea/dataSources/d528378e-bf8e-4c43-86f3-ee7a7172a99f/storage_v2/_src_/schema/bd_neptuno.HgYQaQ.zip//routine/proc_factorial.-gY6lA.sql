create
    definer = root@localhost function proc_factorial(numero int) returns int deterministic
begin
	declare fact int;
	
	set fact = 1;
	
	while numero>1 do
		set fact = fact * numero;
		set numero  = numero - 1;
	end while;
  
	return fact;
end;

