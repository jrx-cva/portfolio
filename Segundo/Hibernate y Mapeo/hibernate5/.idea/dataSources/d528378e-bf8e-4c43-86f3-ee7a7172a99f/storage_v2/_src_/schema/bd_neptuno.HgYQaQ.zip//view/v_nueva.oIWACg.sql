create view v_nueva as
select `bd_neptuno`.`productos`.`id`                  AS `id`,
       `bd_neptuno`.`productos`.`producto`            AS `producto`,
       `bd_neptuno`.`productos`.`proveedor_id`        AS `proveedor_id`,
       `bd_neptuno`.`productos`.`categoria_id`        AS `categoria_id`,
       `bd_neptuno`.`productos`.`cantidad_por_unidad` AS `cantidad_por_unidad`
from (`bd_neptuno`.`productos`
         join `bd_neptuno`.`categorias`
              on ((`bd_neptuno`.`productos`.`categoria_id` = `bd_neptuno`.`categorias`.`id`)));

