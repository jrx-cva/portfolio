create
    definer = root@localhost procedure iva_nota(IN var_iva decimal(4, 2))
BEGIN

	update productos
	set iva = var_iva;

	update productos
	set notas = concat("Producto: ", producto, ". Precio unidad: ", precio_unidad, ". IVA: ", iva, ". Precio unidad con IVA: ", precio_unidad*iva/10);

END;

