create definer = root@localhost trigger clientes_del
    before delete
    on clientes
    for each row
begin
 
 -- Elimino los pedidos de ese cliente
 -- Pero antes necesito eliminar los detalles de cada uno de esos pedidos por tener foreign key
	DELETE FROM detalles 
    WHERE detalles.pedido_id IN (SELECT id 
								from pedidos 
								WHERE pedidos.cliente_id = old.id);
 
 	DELETE 
    FROM pedidos 
	WHERE pedidos.cliente_id = old.id;
 
 
 -- Elimino los registros historicos de ese cliente
--   DELETE FROM clientes_historico 
--   WHERE codigo = old.codigo;
 end;

