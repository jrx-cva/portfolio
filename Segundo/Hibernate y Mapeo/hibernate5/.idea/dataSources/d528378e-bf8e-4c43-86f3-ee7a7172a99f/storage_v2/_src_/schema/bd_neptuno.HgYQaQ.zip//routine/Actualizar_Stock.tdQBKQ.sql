create
    definer = root@localhost procedure Actualizar_Stock(IN var_descripcion varchar(40), IN var_id_categoria int,
                                                        IN var_cantidad smallint)
BEGIN
	IF (SELECT COUNT(*) 
	   FROM Productos 
        WHERE descripcion = var_descripcion 
        AND categoria = id_categoria) = 0 THEN
		UPDATE Productos
		SET unidades_existencia = unidades_existencia + var_cantidad
		WHERE unidades_existencia > 0;
    ELSE 
		INSERT INTO productos (producto, categoria_id, unidades_existencia)
		VALUES (var_descripcion, var_id_categoria, var_cantidad);
    END IF;
END;

