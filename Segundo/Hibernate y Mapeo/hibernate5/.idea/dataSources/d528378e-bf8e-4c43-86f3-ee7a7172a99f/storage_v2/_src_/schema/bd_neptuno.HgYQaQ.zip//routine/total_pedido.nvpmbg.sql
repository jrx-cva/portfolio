create
    definer = root@localhost function total_pedido(var_id int) returns int deterministic
BEGIN
	declare hola int;
    set hola = (select pedido_id, (precio_unidad * cantidad) as 'Total pedido' from detalles 
    inner join productos on detalles.peido_id = productos.id
    where productos.id = var_id);
RETURN hola;
END;

