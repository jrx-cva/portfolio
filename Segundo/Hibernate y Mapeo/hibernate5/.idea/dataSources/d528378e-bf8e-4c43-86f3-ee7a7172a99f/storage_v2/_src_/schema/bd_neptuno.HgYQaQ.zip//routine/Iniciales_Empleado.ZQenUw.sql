create
    definer = root@localhost function Iniciales_Empleado(var_id int) returns varchar(40) deterministic
BEGIN
	declare iniciales varchar(40);
	declare ape varchar(30);
	declare nom varchar(10);

	select nombre, apellidos into nom, ape
    from empleados 
    where id=var_id ;

	set iniciales=upper(concat(left(ape,1),left(nom,1)));

	RETURN iniciales;
END;

