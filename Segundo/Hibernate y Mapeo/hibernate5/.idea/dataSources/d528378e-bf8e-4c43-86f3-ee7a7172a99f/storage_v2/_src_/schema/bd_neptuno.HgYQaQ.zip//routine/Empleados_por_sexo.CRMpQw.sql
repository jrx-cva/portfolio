create
    definer = root@localhost procedure Empleados_por_sexo(IN var_sexo varchar(6))
BEGIN
	IF var_sexo = "HOMBRE" THEN
		SELECT *, edad_empleado(id) edad
		FROM empleados
		where tratamiento IN ('Sr.', 'Dr.');  
    ELSE 
		IF var_sexo = "MUJER" THEN
			SELECT *, edad_empleado(id) edad
			FROM empleados
			where tratamiento IN ('Sra.', 'Dra.', 'Srta.');     
		END IF;
	END IF;
END;

