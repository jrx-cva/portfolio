create definer = root@localhost trigger beforeInsertPedidos
    before insert
    on pedidos
    for each row
BEGIN
	DECLARE v_Destinatario,
			v_DireccionDestinatario,
			v_CiudadDestinatario,
			v_RegionDestinatario,
			v_CodPostalDestinatario,
			v_PaisDestinatario
				VARCHAR(100);

	SELECT Contacto, Direccion, Ciudad, Region, cp, Pais
			INTO v_Destinatario, v_DireccionDestinatario, v_CiudadDestinatario, v_RegionDestinatario, v_CodPostalDestinatario, v_PaisDestinatario
	FROM Clientes
	WHERE Id = new.Id;

	IF ISNULL(new.Destinatario) THEN SET new.Destinatario = v_Destinatario; END IF;
	IF ISNULL(new.Direccion_Destinatario) THEN SET new.Direccion_Destinatario = v_DireccionDestinatario; END IF;
	IF ISNULL(new.Ciudad_Destinatario) THEN SET new.Ciudad_Destinatario = v_CiudadDestinatario; END IF;
	IF ISNULL(new.Region_Destinatario) THEN SET new.Region_Destinatario = v_RegionDestinatario; END IF;
	IF ISNULL(new.cp_Destinatario) THEN SET new.cp_Destinatario = v_CodPostalDestinatario; END IF;
	IF ISNULL(new.Pais_Destinatario) THEN SET new.Pais_Destinatario = v_PaisDestinatario; END IF;
END;

