
import bbdd.Conexion;

import java.sql.Connection;

public class main {

    public static void main(String args[]) {
        //siempre igual
        Conexion conexion = new Conexion();
        //

    }

}