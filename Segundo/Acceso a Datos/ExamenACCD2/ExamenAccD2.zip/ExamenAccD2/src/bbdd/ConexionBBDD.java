package bbdd;

public class ConexionBBDD {

}
