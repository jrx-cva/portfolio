package com.carmen.me;

import java.awt.event.ActionEvent;
import java.util.Scanner;

import javax.swing.JOptionPane;

import clasesHechas.Productos;
import com.carmen.me.ObtenerProductos;

public class Main {
	public static void main (String[] args) {
		almacenarProductosEnFichero();
		
	}
	
	public static void almacenarProductosEnFichero() {
		//public void actionPerformed(ActionEvent e) {
		obtener();
	}

	private static void obtener() {
		
		System.out.println("Digame el identificador de categor�a");
		String entradaTeclado = "";
		Scanner entradaScanner = new Scanner(System.in);
		entradaTeclado = entradaScanner.nextLine (); //Invocamos un m�todo sobre un objeto Scanner
		//System.out.println ("Entrada recibida por teclado es: \"" + entradaTeclado +"\"");
		
		//instanciar clase gestionUsuario
		ObtenerProductos productos = new ObtenerProductos();
		
		Productos pro = new Productos();
		Productos pro2 = productos.obtenerProductos(pro);
		
		
	}
	
}
