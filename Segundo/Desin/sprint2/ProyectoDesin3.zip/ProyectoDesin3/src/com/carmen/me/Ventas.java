package com.carmen.me;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ventas extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventas frame = new Ventas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventas() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 23, 117, 216);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lbVehiculos = new JLabel("VEH\u00CDCULOS");
		lbVehiculos.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lbVehiculos.setBounds(20, 11, 74, 14);
		panel.add(lbVehiculos);
		
		JButton btnVehiculos = new JButton("Todos los veh�culos y datos");
		btnVehiculos.setToolTipText("");
		btnVehiculos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnVehiculos.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnVehiculos.setBounds(10, 61, 97, 119);
		panel.add(btnVehiculos);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(159, 23, 117, 216);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CLIENTES");
		lblNewLabel.setBounds(35, 5, 46, 14);
		panel_1.add(lblNewLabel);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(307, 23, 117, 216);
		contentPane.add(panel_2);
	}
}
