package com.carmen.me;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JScrollBar;
import java.awt.FlowLayout;

public class PanelVeh�culo extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PanelVeh�culo frame = new PanelVeh�culo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PanelVeh�culo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 434, 44);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		JLabel lblveh�culo2 = new JLabel("VEH\u00CDCULO");
		lblveh�culo2.setBounds(176, 11, 82, 23);
		lblveh�culo2.setForeground(Color.BLACK);
		lblveh�culo2.setFont(new Font("SansSerif", Font.PLAIN, 17));
		panel.add(lblveh�culo2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(43, 56, 347, 178);
		contentPane.setBackground(new Color(233,196,106));
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lbl1 = new JLabel("N\u00FAmero de bastidor:");
		lbl1.setBounds(10, 11, 113, 16);
		lbl1.setFont(new Font("SansSerif", Font.PLAIN, 12));
		panel_1.add(lbl1);
		
		JLabel lbl2 = new JLabel("Matr\u00EDcula:");
		lbl2.setBounds(10, 38, 113, 16);
		lbl2.setFont(new Font("SansSerif", Font.PLAIN, 12));
		panel_1.add(lbl2);
		
		JLabel lbl3 = new JLabel("Marca:");
		lbl3.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl3.setBounds(10, 65, 113, 14);
		panel_1.add(lbl3);
		
		JLabel lbl4 = new JLabel("Modelo:");
		lbl4.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl4.setBounds(10, 90, 113, 14);
		panel_1.add(lbl4);
		
		JLabel lbl5 = new JLabel("Tipo de vehiculo:");
		lbl5.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl5.setBounds(10, 115, 113, 14);
		panel_1.add(lbl5);
		
		JLabel lblNum_bastidor = new JLabel("");
		lblNum_bastidor.setBackground(Color.WHITE);
		lblNum_bastidor.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblNum_bastidor.setBounds(124, 13, 46, 14);
		panel_1.add(lblNum_bastidor);
		
		JLabel lblMatricula = new JLabel("");
		lblMatricula.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblMatricula.setBounds(124, 38, 46, 14);
		panel_1.add(lblMatricula);
		
		JLabel lblMarca = new JLabel("");
		lblMarca.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblMarca.setBounds(124, 66, 46, 14);
		panel_1.add(lblMarca);
		
		JLabel lblModelo = new JLabel("");
		lblModelo.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblModelo.setBounds(124, 91, 46, 14);
		panel_1.add(lblModelo);
		
		JLabel lblTipo_vehiculo = new JLabel("");
		lblTipo_vehiculo.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblTipo_vehiculo.setBounds(124, 115, 46, 14);
		panel_1.add(lblTipo_vehiculo);
		
		JLabel lbl6 = new JLabel("Color:");
		lbl6.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl6.setBounds(192, 13, 74, 14);
		panel_1.add(lbl6);
		
		JLabel lbl7 = new JLabel("Potencia:");
		lbl7.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl7.setBounds(192, 40, 74, 14);
		panel_1.add(lbl7);
		
		JLabel lbl8 = new JLabel("A\u00F1o:");
		lbl8.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl8.setBounds(192, 66, 74, 14);
		panel_1.add(lbl8);
		
		JLabel lbl9 = new JLabel("Combustible:");
		lbl9.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl9.setBounds(192, 91, 74, 14);
		panel_1.add(lbl9);
		
		JLabel lbl10 = new JLabel("Precio:");
		lbl10.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl10.setBounds(192, 116, 74, 14);
		panel_1.add(lbl10);
		
		JLabel lblColor = new JLabel("");
		lblColor.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblColor.setBackground(Color.WHITE);
		lblColor.setBounds(276, 13, 46, 14);
		panel_1.add(lblColor);
		
		JLabel lblPotencia = new JLabel("");
		lblPotencia.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblPotencia.setBackground(Color.WHITE);
		lblPotencia.setBounds(276, 40, 46, 14);
		panel_1.add(lblPotencia);
		
		JLabel lblAnio = new JLabel("");
		lblAnio.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblAnio.setBackground(Color.WHITE);
		lblAnio.setBounds(276, 66, 46, 14);
		panel_1.add(lblAnio);
		
		JLabel lblCombustible = new JLabel("");
		lblCombustible.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblCombustible.setBackground(Color.WHITE);
		lblCombustible.setBounds(276, 91, 46, 14);
		panel_1.add(lblCombustible);
		
		JLabel lblPrecio = new JLabel("");
		lblPrecio.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblPrecio.setBackground(Color.WHITE);
		lblPrecio.setBounds(276, 116, 46, 14);
		panel_1.add(lblPrecio);
		
		JLabel lbl11 = new JLabel("Descripci\u00F3n:");
		lbl11.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl11.setBounds(10, 140, 69, 14);
		panel_1.add(lbl11);
		
		JLabel lblDescripcion_vehiculo = new JLabel("");
		lblDescripcion_vehiculo.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblDescripcion_vehiculo.setBounds(91, 140, 246, 27);
		panel_1.add(lblDescripcion_vehiculo);
		
		
	}
}
