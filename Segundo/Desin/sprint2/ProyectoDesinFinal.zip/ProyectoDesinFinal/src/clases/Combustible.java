package clases;

/**
 * 
 * @author Carmen
 *
 */
public enum Combustible {
	Gasolina, Gasoil, Electrico, Hibrido
}
