package clases;

/**
 * 
 * @author Laura
 *
 * En esta clase tendremos los datos de los Propuesta de la aplicacion
 */

public class Propuesta {

	/**
	 * Definimos los atributos de usuarios
	 */
	
	int idPropuesta, idVentas, idCliente, idVehiculo;
	float precioPropuesta;
	String nombre_usuario, fechaPropuesta, fechaValidez, descripcionPropuesta;
	
	/**
	 * Creamos un constructor vacio siempre esta bien tenerlo
	 */
	public Propuesta() {
	}
	
	/**
	 * Constructor al que le pasamos los parametros que sera los que les pasemos de la BBDD o lo introduzcamos nosotros.
	 * @param idPropuesta
	 * @param idVentas
	 * @param idCliente
	 * @param idVehiculo
	 * @param precioPropuesta
	 * @param fechaPropuesta
	 * @param fechaValidez
	 * @param descrpcionPropuesta
	 */
	public Propuesta(int idPropuesta,int idVentas,int idCliente,int idVehiculo,float precioPropuesta, 
				String nombre_usuario, String fechaPropuesta, String fechaValidez, String descrpcionPropuesta) {
		this.idPropuesta = idPropuesta;
		this.idVentas = idVentas;
		this.idCliente = idCliente;
		this.idVehiculo = idVehiculo;
		this.precioPropuesta = precioPropuesta;
		this.nombre_usuario = nombre_usuario;
		this.fechaPropuesta = fechaPropuesta;
		this.fechaValidez = fechaValidez;
		this.descripcionPropuesta = descrpcionPropuesta;
		
	}
	
	public String getNombre_usuario() {
		return nombre_usuario;
	}

	public void setNombre_usuario(String nombre_cliente) {
		this.nombre_usuario = nombre_cliente;
	}

	/**
	 * Realizamos los Setters and Getters
	 */

	public int getIdPropuesta() {
		return idPropuesta;
	}

	public void setIdPropuesta(int idPropuesta) {
		this.idPropuesta = idPropuesta;
	}

	public int getIdVentas() {
		return idVentas;
	}

	public void setIdVentas(int idVentas) {
		this.idVentas = idVentas;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public int getIdVehiculo() {
		return idVehiculo;
	}

	public void setIdVehiculo(int idVehiculo) {
		this.idVehiculo = idVehiculo;
	}

	public float getPrecioPropuesta() {
		return precioPropuesta;
	}

	public void setPrecioPropuesta(float precioPropuesta) {
		this.precioPropuesta = precioPropuesta;
	}

	public String getFechaPropuesta() {
		return fechaPropuesta;
	}

	public void setFechaPropuesta(String fechaPropuesta) {
		this.fechaPropuesta = fechaPropuesta;
	}

	public String getFechaValidez() {
		return fechaValidez;
	}

	public void setFechaValidez(String fechaValidez) {
		this.fechaValidez = fechaValidez;
	}

	public String getDescripcionPropuesta() {
		return descripcionPropuesta;
	}

	public void setDescripcionPropuesta(String descripcionPropuesta) {
		this.descripcionPropuesta = descripcionPropuesta;
	}

	@Override
	public String toString() {
		return "Propuesta [idPropuesta=" + idPropuesta + ", idVentas=" + idVentas + ", idCliente=" + idCliente
				+ ", idVehiculo=" + idVehiculo + ", precioPropuesta=" + precioPropuesta + ", nombre_usuario="
				+ nombre_usuario + ", fechaPropuesta=" + fechaPropuesta + ", fechaValidez=" + fechaValidez
				+ ", descripcionPropuesta=" + descripcionPropuesta + ", getNombre_usuario()=" + getNombre_usuario()
				+ ", getIdPropuesta()=" + getIdPropuesta() + ", getIdVentas()=" + getIdVentas() + ", getIdCliente()="
				+ getIdCliente() + ", getIdVehiculo()=" + getIdVehiculo() + ", getPrecioPropuesta()="
				+ getPrecioPropuesta() + ", getFechaPropuesta()=" + getFechaPropuesta() + ", getFechaValidez()="
				+ getFechaValidez() + ", getDescripcionPropuesta()=" + getDescripcionPropuesta() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}


}
