package gestion;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import bbdd.BBdd;

public class RealizaPropuesta {

	int idPropuesta, idVentas, idCliente, idVehiculo;
	float precioPropuesta;
	String fechaPropuesta, fechaValidez, descripcionPropuesta;
	
	/**
	 * Esta funcion inserta en la base de datos una nueva propuesta dato sus datos.
	 * @param idVentas
	 * @param idCliente
	 * @param idVehiculo
	 * @param precioPropuesta
	 * @param fechaPropuesta
	 * @param fechaValidez
	 * @param descrpcionPropuesta
	 */
	public void registrarPropuesta (int idVentas,int idCliente,int idVehiculo,float precioPropuesta, 
			String fechaPropuesta, String fechaValidez, String descrpcionPropuesta) {
		
		this.idVentas = idVentas;
		this.idCliente = idCliente;
		this.idVehiculo = idVehiculo;
		this.precioPropuesta = precioPropuesta;
		this.fechaPropuesta = fechaPropuesta;
		this.fechaValidez = fechaValidez;
		this.descripcionPropuesta = descrpcionPropuesta;
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		//conexion
		try {
			
			/**
			 * Conectamos con la bbdd e introducimos el objeto mediante un insert a la tabla correspondiente.
			 */
			con = BBdd.conectar();
			String sql = "insert into vehiculo (id_ventas, id_cliente, id_vehiculo, precio_propuesta, fecha_propuesta, fecha_validez, descripcion_propuesta) "
					+ "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			
			pst = con.prepareStatement(sql);
			pst.setInt(2, idVentas);
			pst.setInt(3, idCliente);
			pst.setInt(4, idVehiculo);
			pst.setFloat(5, precioPropuesta);
			pst.setString(6, fechaPropuesta);
			pst.setString(7, fechaValidez);
			pst.setString(8, descrpcionPropuesta);
			
			rs = pst.executeQuery();
			
		} catch (Exception e) {
			System.out.println("Error al introsucir propuesta");
		}
		
	}

}
