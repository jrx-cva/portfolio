package com.carmen.me;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import clases.Vehiculo;
import gestion.BusquedaVehiculo;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JScrollBar;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

/**
 * 
 * @author Carmen
 *
 */
public class VerVehiculo extends JFrame {

	private JPanel contentPane;
	private JButton btnOkVerVehiculos;
	private JTextField tfNumBastidorVerVehiculo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VerVehiculo frame = new VerVehiculo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VerVehiculo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 434, 44);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		JLabel lblVerVehiculo = new JLabel("Ver veh\u00EDculo");
		lblVerVehiculo.setBounds(171, 11, 98, 23);
		lblVerVehiculo.setForeground(Color.BLACK);
		lblVerVehiculo.setFont(new Font("SansSerif", Font.PLAIN, 17));
		panel.add(lblVerVehiculo);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(25, 57, 333, 166);
		contentPane.setBackground(new Color(233,196,106));
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lbl1 = new JLabel("N\u00FAmero de bastidor:");
		lbl1.setBounds(10, 11, 113, 16);
		lbl1.setFont(new Font("SansSerif", Font.PLAIN, 12));
		panel_1.add(lbl1);
		
		JLabel lbl2 = new JLabel("Matr\u00EDcula:");
		lbl2.setBounds(10, 38, 113, 16);
		lbl2.setFont(new Font("SansSerif", Font.PLAIN, 12));
		panel_1.add(lbl2);
		
		JLabel lbl3 = new JLabel("Marca:");
		lbl3.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl3.setBounds(10, 65, 113, 14);
		panel_1.add(lbl3);
		
		JLabel lbl4 = new JLabel("Modelo:");
		lbl4.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl4.setBounds(10, 90, 113, 14);
		panel_1.add(lbl4);
		
		JLabel lbl5 = new JLabel("Tipo de vehiculo:");
		lbl5.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl5.setBounds(10, 115, 113, 14);
		panel_1.add(lbl5);
		
		JLabel lblMatricula = new JLabel("");
		lblMatricula.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblMatricula.setBounds(124, 38, 46, 14);
		lblMatricula.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblMatricula);
		
		JLabel lblMarca = new JLabel("");
		lblMarca.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblMarca.setBounds(124, 66, 46, 14);
		lblMarca.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblMarca);
		
		JLabel lblModelo = new JLabel("");
		lblModelo.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblModelo.setBounds(124, 91, 46, 14);
		lblModelo.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblModelo);
		
		JLabel lblTipo_vehiculo = new JLabel("");
		lblTipo_vehiculo.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblTipo_vehiculo.setBounds(124, 115, 46, 14);
		lblTipo_vehiculo.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblTipo_vehiculo);
		
		JLabel lbl6 = new JLabel("Color:");
		lbl6.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl6.setBounds(192, 13, 74, 14);
		panel_1.add(lbl6);
		
		JLabel lbl7 = new JLabel("Potencia:");
		lbl7.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl7.setBounds(192, 40, 74, 14);
		panel_1.add(lbl7);
		
		JLabel lbl8 = new JLabel("A\u00F1o:");
		lbl8.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl8.setBounds(192, 66, 74, 14);
		panel_1.add(lbl8);
		
		JLabel lbl9 = new JLabel("Combustible:");
		lbl9.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl9.setBounds(192, 91, 74, 14);
		panel_1.add(lbl9);
		
		JLabel lbl10 = new JLabel("Precio:");
		lbl10.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl10.setBounds(192, 116, 74, 14);
		panel_1.add(lbl10);
		
		JLabel lblColor = new JLabel("");
		lblColor.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblColor.setBackground(Color.WHITE);
		lblColor.setBounds(276, 13, 46, 14);
		lblColor.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblColor);
		
		JLabel lblPotencia = new JLabel("");
		lblPotencia.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblPotencia.setBackground(Color.WHITE);
		lblPotencia.setBounds(276, 40, 46, 14);
		lblPotencia.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblPotencia);
		
		JLabel lblAnio = new JLabel("");
		lblAnio.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblAnio.setBackground(Color.WHITE);
		lblAnio.setBounds(276, 66, 46, 14);
		lblAnio.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblAnio);
		
		JLabel lblCombustible = new JLabel("");
		lblCombustible.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblCombustible.setBackground(Color.WHITE);
		lblCombustible.setBounds(276, 91, 46, 14);
		lblCombustible.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblCombustible);
		
		JLabel lblPrecio = new JLabel("");
		lblPrecio.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblPrecio.setBackground(Color.WHITE);
		lblPrecio.setBounds(276, 116, 46, 14);
		lblPrecio.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblPrecio);
		
		JLabel lbl11 = new JLabel("Descripci\u00F3n:");
		lbl11.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lbl11.setBounds(10, 140, 69, 14);
		panel_1.add(lbl11);
		
		JLabel lblDescripcion_vehiculo = new JLabel("");
		lblDescripcion_vehiculo.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblDescripcion_vehiculo.setBounds(91, 140, 232, 15);
		lblDescripcion_vehiculo.setBorder(BorderFactory.createTitledBorder(""));
		panel_1.add(lblDescripcion_vehiculo);
		
		tfNumBastidorVerVehiculo = new JTextField();
		tfNumBastidorVerVehiculo.setBackground(Color.WHITE);
		tfNumBastidorVerVehiculo.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tfNumBastidorVerVehiculo.setBounds(129, 10, 53, 20);
		panel_1.add(tfNumBastidorVerVehiculo);
		tfNumBastidorVerVehiculo.setColumns(10);
		
		/**
		 * Bot�n que pulsa para buscar veh�culos
		 */
		btnOkVerVehiculos = new JButton("Buscar");
		btnOkVerVehiculos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscar();
			}

			private void buscar() {
				// TODO Auto-generated method stub
				String numero_bastidor = tfNumBastidorVerVehiculo.getText();
				
				//instancia clase BusquedaVehiculo
				BusquedaVehiculo busquedavehiculo = new BusquedaVehiculo();
				
				Vehiculo vehiculo2 = new Vehiculo();
				vehiculo2.setNumBastidor(numero_bastidor);
								
				Vehiculo vehi = busquedavehiculo.obtenerVehiculo(vehiculo2);
				
				if (vehi != null) {
					JOptionPane.showMessageDialog(contentPane, "Okay");
					
				} else
					JOptionPane.showMessageDialog(contentPane, "No hay ning�n coche");
				
				
			}
		});
		btnOkVerVehiculos.setBackground(Color.WHITE);
		btnOkVerVehiculos.setFont(new Font("SansSerif", Font.PLAIN, 11));
		btnOkVerVehiculos.setBounds(331, 227, 93, 23);
		contentPane.add(btnOkVerVehiculos);
		
		
	}
}
