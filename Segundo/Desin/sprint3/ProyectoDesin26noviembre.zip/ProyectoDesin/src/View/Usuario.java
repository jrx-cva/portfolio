package View;

public class Usuario {

}
