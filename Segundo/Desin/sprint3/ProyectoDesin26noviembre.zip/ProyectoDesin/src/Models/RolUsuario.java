package Models;

/*
* Esta clase muestra como solo se puede elegir entre las opci�n que
* la componen.
*/
public enum RolUsuario {

	Jefe, Mecanico, Ventas;
}
