package Models;

/*
* Esta clase clase muestra como solo se puede elegir entre las opci�n que
* la componen.
*/
public enum TipoVehiculo {
	Nuevo, SegundaMano, Km0
}
