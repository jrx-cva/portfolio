package clases;

/**
 * 
 * @author Laura
 *
 * En esta clase tendremos los datos de los Propuesta de la aplicacion
 */

public class Propuesta {

	/**
	 * Definimos los atributos de usuarios
	 */
	
	Integer idPropuesta, idVentas, idCliente, idVehiculo;
	Float precioPropuesta;
	String nombre_usuario, fechaPropuesta, fechaValidez, descripcionPropuesta;
	
	/**
	 * Creamos un constructor vacio siempre esta bien tenerlo
	 */
	public Propuesta() {
	}
	
	/**
	 * Constructor al que le pasamos los parametros que sera los que les pasemos de la BBDD o lo Integerroduzcamos nosotros.
	 * @param idPropuesta
	 * @param idVentas
	 * @param idCliente
	 * @param idVehiculo
	 * @param precioPropuesta
	 * @param fechaPropuesta
	 * @param fechaValidez
	 * @param descrpcionPropuesta
	 */
	public Propuesta(Integer idPropuesta,Integer idVentas,Integer idCliente,Integer idVehiculo,Float precioPropuesta, 
				String nombre_usuario, String fechaPropuesta, String fechaValidez, String descrpcionPropuesta) {
		this.idPropuesta = idPropuesta;
		this.idVentas = idVentas;
		this.idCliente = idCliente;
		this.idVehiculo = idVehiculo;
		this.precioPropuesta = precioPropuesta;
		this.nombre_usuario = nombre_usuario;
		this.fechaPropuesta = fechaPropuesta;
		this.fechaValidez = fechaValidez;
		this.descripcionPropuesta = descrpcionPropuesta;
		
	}
	
	public String getNombre_usuario() {
		return nombre_usuario;
	}

	public void setNombre_usuario(String nombre_cliente) {
		this.nombre_usuario = nombre_cliente;
	}

	/**
	 * Realizamos los Setters and Getters
	 */

	public Integer getIdPropuesta() {
		return idPropuesta;
	}

	public void setIdPropuesta(Integer idPropuesta) {
		this.idPropuesta = idPropuesta;
	}

	public Integer getIdVentas() {
		return idVentas;
	}

	public void setIdVentas(Integer idVentas) {
		this.idVentas = idVentas;
	}

	public Integer getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}

	public Integer getIdVehiculo() {
		return idVehiculo;
	}

	public void setIdVehiculo(Integer idVehiculo) {
		this.idVehiculo = idVehiculo;
	}

	public Float getPrecioPropuesta() {
		return precioPropuesta;
	}

	public void setPrecioPropuesta(Float precioPropuesta) {
		this.precioPropuesta = precioPropuesta;
	}

	public String getFechaPropuesta() {
		return fechaPropuesta;
	}

	public void setFechaPropuesta(String fechaPropuesta) {
		this.fechaPropuesta = fechaPropuesta;
	}

	public String getFechaValidez() {
		return fechaValidez;
	}

	public void setFechaValidez(String fechaValidez) {
		this.fechaValidez = fechaValidez;
	}

	public String getDescripcionPropuesta() {
		return descripcionPropuesta;
	}

	public void setDescripcionPropuesta(String descripcionPropuesta) {
		this.descripcionPropuesta = descripcionPropuesta;
	}

	@Override
	public String toString() {
		return "Propuesta:  precioPropuesta=" + precioPropuesta + ", nombre_usuario="
				+ nombre_usuario + ", fechaPropuesta=" + fechaPropuesta + ", fechaValidez=" + fechaValidez
				+ ", descripcionPropuesta=" + descripcionPropuesta + ", getNombre_usuario()=" + getNombre_usuario()
				+ ", getIdPropuesta()=" + getIdPropuesta() + ", getIdVentas()=" + getIdVentas() + ", getIdCliente()="
				+ getIdCliente() + ", getIdVehiculo()=" + getIdVehiculo() + ", getPrecioPropuesta()="
				+ getPrecioPropuesta() + ", getFechaPropuesta()=" + getFechaPropuesta() + ", getFechaValidez()="
				+ getFechaValidez() + ", getDescripcionPropuesta()=" + getDescripcionPropuesta() + ", hashCode()=" + hashCode();
	}


}
