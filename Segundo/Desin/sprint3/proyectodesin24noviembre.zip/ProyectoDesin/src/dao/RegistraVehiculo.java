package dao;


import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import bbdd.BBdd;
import clases.Vehiculo;

/**
 * Esta clase 
 * @author Laura
 *
 */
public class RegistraVehiculo {
	
	int idVehiculo, idConcesionario, idCliente, idVentas;
	String numBastidor, matricula, marca, modelo, color, potencia, anio, descripcionVeehiculo, combustible, tipoVehiculo;
	float precio;
	
	public void registrarVehiculo (int idConcesionario, int idCliente, int idVentas, String numBastidor, String matricula, String marca, 
			String modelo, String tipoVehiculo, String color, String potencia, String anio, String combustible, float precio,
			String descripcionVeehiculo) {
		
		this.idConcesionario = idConcesionario;
		this.idCliente = idCliente;
		this.idVentas = idVentas;
		this.numBastidor = numBastidor;
		this.matricula = matricula;
		this.marca = marca;
		this.modelo = modelo;
		this.tipoVehiculo = tipoVehiculo;
		this.color = color;
		this.potencia = potencia;
		this.anio = anio;
		this.combustible = combustible;
		this.precio = precio;
		this.descripcionVeehiculo = descripcionVeehiculo;
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		//conexion
		try {
			con = BBdd.conectar();
			String sql = "insert into vehiculo (id_concesionario, id_cliente, id_ventas, num_bastidor, matricula, marca, \r\n" + 
					"modelo, tipo_vehiculo, color, potencia, anio, combustible, precio, descripcion_vehiculo) "
					+ "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			
			pst = con.prepareStatement(sql);
			pst.setInt(2, idConcesionario); // id_concesionario
			pst.setInt(3, idCliente);
			pst.setInt(4, idVentas);
			pst.setString(5, numBastidor);
			pst.setString(6, matricula);
			pst.setString(7, modelo);
			pst.setString(8, tipoVehiculo);
			pst.setString(9, color);
			pst.setString(10, potencia);
			pst.setString(11, anio);
			pst.setString(12, combustible);
			pst.setFloat(13, precio);
			pst.setString(14, descripcionVeehiculo);
			
			rs = pst.executeQuery();
			
		} catch (Exception e) {
			System.out.println("Error al introducir cliente");
		}
		
	}

}
