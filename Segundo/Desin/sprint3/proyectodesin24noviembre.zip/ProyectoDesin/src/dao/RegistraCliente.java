package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import bbdd.BBdd;
import clases.Clientes;
import clases.Vehiculo;

public class RegistraCliente {

	String nombreCliente, dniCliente, emailCliente, numCuenta;
	
	public void registrarCliente (String nombreCliente, String dniCliente, String emailCliente,String numCuenta) {
		
		this.nombreCliente = nombreCliente;
		this.dniCliente = dniCliente;
		this.emailCliente = emailCliente;
		this.numCuenta = numCuenta;
		
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		//conexion
		try {
			con = BBdd.conectar();
			String sql = "insert into cliente (nombre_cliene, nif_cliente, email_cliente, num_cuenta)";
			
			
			pst = con.prepareStatement(sql);
			pst.setString(2, nombreCliente);
			pst.setString(3, dniCliente);
			pst.setString(4, emailCliente);
			pst.setString(5, numCuenta);
						
			rs = pst.executeQuery();
			
		} catch (Exception e) {
			System.out.println("Error al a�adir cliente");
		}
	}
}
