package clases;

public enum TipoEmision {
	O, B, ECO,C
}
