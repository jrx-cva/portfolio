package clases;

/**
 * 
 * @author Carmen
 *
 */
public enum TipoVehiculo {
	Nuevo, SegundaMano, Km0
}
